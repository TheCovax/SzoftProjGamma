package Fungorium.src.view;

public class MapView {
}
