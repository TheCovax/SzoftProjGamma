package Fungorium.src.view;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class GameView extends JFrame {

    private MapView mapView;
    private TektonPanel tektonPanel;
    private EntityPanel entityPanel;
    private GamePanel gamePanel;
    private ActionPanel actionPanel;

    public GameView() {
        setTitle("Fungorium - Strategy Game");
        setSize(1280, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Initialize panels
        mapView = new MapView();
        tektonPanel = new TektonPanel();
        entityPanel = new EntityPanel();
        gamePanel = new GamePanel();
        actionPanel = new ActionPanel();

        // Layout setup
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BorderLayout());
        rightPanel.add(tektonPanel, BorderLayout.CENTER);
        rightPanel.add(entityPanel, BorderLayout.SOUTH);

        add(gamePanel, BorderLayout.NORTH);
        add(mapView, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.EAST);
        add(actionPanel, BorderLayout.SOUTH);

        // Key listener for user actions
        addKeyListener(new KeyListener() {
            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e.getKeyCode());
            }

            @Override
            public void keyReleased(KeyEvent e) {}

            @Override
            public void keyTyped(KeyEvent e) {}
        });

        setFocusable(true);
        setVisible(true);
    }

    private void handleKeyPress(int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_R:
                // Switch to next entity (Rovar or GombaTest)
                //mapView.selectNextEntity();
                break;
            case KeyEvent.VK_N:
                // Skip to next player
                System.out.println("Next player");
                break;
            case KeyEvent.VK_G:
                // Activate Grow Fonal Mode
                System.out.println("Grow Fonal Mode");
                break;
            case KeyEvent.VK_S:
                // Shoot Spora
                System.out.println("Shoot Spora");
                break;
            case KeyEvent.VK_U:
                // Upgrade GombaTest
                System.out.println("Upgrade GombaTest");
                break;
            case KeyEvent.VK_M:
                // Move Rovar
                System.out.println("Move Rovar");
                break;
            case KeyEvent.VK_C:
                // Cut GombaFonal
                System.out.println("Cut GombaFonal");
                break;
            case KeyEvent.VK_E:
                // Eat Spora
                System.out.println("Eat Spora");
                break;
        }
    }

    public void updateView() {
        //mapView.repaint();
        //tektonPanel.updatePanel();
        //entityPanel.updatePanel();
        //gamePanel.updatePanel();
        //actionPanel.updatePanel();
    }
}
