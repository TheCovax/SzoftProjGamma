package Fungorium.src.view;

public class EntityPanel {
}
